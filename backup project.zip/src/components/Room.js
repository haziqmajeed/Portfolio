// If we want to use this software publically
//Use stun server
// use your local IP when creating socket.io


import React, { Component } from 'react';
import io from 'socket.io-client'
import SingleVideo from './Videos/SingleVideo'
import Vids from './Videos/Vids'
import queryString from 'query-string';
import Host from './Videos/Host';
class Room extends Component {
  constructor(props) {
    super(props)

    this.state = {
      localStream: null,    
      remoteConnections: [],    
      peerConnections: {},     
      remoteNames:[],
      remoteStreams:[],
      

      //ye stun server ha firewall break krnay ke liyey used in RTCPeerConnection(pc_config)
      // pc_config: {
      //   "iceServers": [ 
      //     {
      //       urls : 'stun:stun.l.google.com:19302'
      //     }
      //   ]
      // },

      sdpConstraints: {
        'mandatory': {
            'OfferToReceiveAudio': true,
            'OfferToReceiveVideo': true
        }
      },
    }

   
    //this.serviceIP = 'http://localhost:8080/webrtcPeer'
    this.socket = null
    
    this.room = null;
    this.name = null;

    
  }

  getLocalStream = () => {
  
    const success = (stream) => {
     
     console.log("MY STREAM:",stream)
      this.setState({
        localStream: stream
      })

      this.whoisOnline()
    }

  
    const failure = (e) => {
      console.log('getUserMedia Error: ', e)
    }

  
    const constraints = {
      // audio: true,
      video: true,
     
      options: {
        mirror: true,
      }
    }

    navigator.mediaDevices.getUserMedia(constraints)
      .then(success)
      .catch(failure)
  }

  whoisOnline = () => {
    this.socket.emit('onlinePeers', {id:this.socket.id,room:this.room,name:this.name})
  }

  createPeerConnection = (socketID, callback) => {

    try {
      let pc = new RTCPeerConnection(null)
      

    
     
      this.setState({
        peerConnections:{ ...this.state.peerConnections, [socketID]: pc }
      })

      pc.onicecandidate = (e) => {

        
        if (e.candidate) {
          this.socket.emit('candidate',{candidate:e.candidate,local:this.socket.id,remote:socketID})
        }
      }

      pc.oniceconnectionstatechange = (e) => {
       console.log("oniceconnectionstatechange:",e)

      }
      

      pc.ontrack = (e) => {    
       
        this.setState({
          remoteStreams:[...this.state.remoteStreams,e.streams[0]]
        })

        this.socket.emit('getNames',{room:this.room,id:this.socket.id})

          this.socket.on('getNames', data => {     
            

           if (this.state.remoteConnections.length == 0 ){
             const remoteVideo = {
               id:data.id,
               name:data.name,
               stream:e.streams[0],
             }
             this.setState({
               remoteConnections:[...this.state.remoteConnections,remoteVideo]
             })

           }
           else{
            const remoteVideo = {
              id:data.id,
              name:data.name,
              stream:e.streams[0],
            }
            let stream=true;
            let names=true;
            let id= true;
             for(var i=0;i < this.state.remoteConnections.length;i++){

               if(this.state.remoteConnections[i].stream === e.streams[0]){
                stream=false;
                
               }
               


             }

             for(var i=0;i < this.state.remoteConnections.length;i++){

              if(this.state.remoteConnections[i].name === data.name){
                names=false;
            
              }
              


            }

            for(var i=0;i < this.state.remoteConnections.length;i++){

              if(this.state.remoteConnections[i].id === data.id){
                id=false;
            
              }
              


            }

             if(stream===true && names===true && id ===true){
              this.setState({
                remoteConnections:[...this.state.remoteConnections,remoteVideo]
              })
             }


           }
            

                
                
              
              
          })
          
        



      }

      pc.close = () => {
      
      }

      if (this.state.localStream)
        pc.addStream(this.state.localStream)

     
      callback(pc)

    } catch(e) {
      console.log('Something went wrong! pc not created!!', e)
     
      callback(null)
    }
  }



  componentDidMount = () => {

    this.socket = io(
      "/webrtcPeer", // used local host address
      {
        path: '/haziq',
        query: {}
      }
    )

    
    // start from here
    this.socket.on('connection-success', myId => {
      const { name, room } = queryString.parse(this.props.location.search); // FOR ROOM CREATING
      this.name=name;
      this.room=room;

      console.log("ROOM:", this.room)
      console.log("NAME:", this.name)

      this.getLocalStream()

      
      

      
    })

    this.socket.on('peer-disconnected', data => {
      console.log('peer-disconnected', data)
      
    //   const remoteConnections = this.state.remoteConnections.filter(temp => temp.id !== data.socketID);

    //   this.setState(prevState => {
        
    //     return { 
    //       remoteConnections,
    //      };
    // });


console.log("NEW ARRAY:", this.state.remoteConnections)





    })

  

    this.socket.on('online-peer', socketID => {
      
      
   
      this.createPeerConnection(socketID, pc => {
     
          if (pc)
            pc.createOffer(this.state.sdpConstraints)
              .then(sdp => {
                pc.setLocalDescription(sdp)
                this.socket.emit('offer',{sdp,local:this.socket.id,remote:socketID})
          })
        })
    })

    this.socket.on('offer', data => {
     
      


      this.createPeerConnection(data.socketID, pc => {
        pc.addStream(this.state.localStream)

        pc.setRemoteDescription(new RTCSessionDescription(data.sdp)).then(() => {
    
          pc.createAnswer(this.state.sdpConstraints)
            .then(sdp => {
              pc.setLocalDescription(sdp)
              this.socket.emit('answer',{sdp,local:this.socket.id,remote:data.socketID})
            })
        })
      })
    })

    this.socket.on('answer', data => {

      const pc = this.state.peerConnections[data.socketID]
  
      pc.setRemoteDescription(new RTCSessionDescription(data.sdp)).then(()=>{})
    })

    this.socket.on('candidate', (data) => {
      const pc = this.state.peerConnections[data.local]
 
      if (pc)
        pc.addIceCandidate(new RTCIceCandidate(data.candidate))
    })

    

  }

 

  

  render() {
    console.log("remoteConnections :",this.state.remoteConnections)
    console.log("remoteStreams:",this.state.remoteStreams)
    return (
      <div>
        <Host localStream={this.state.localStream} myName={this.name}/>         
        <Vids remoteStreams={this.state.remoteConnections}/>              
      </div>
    )
  }
}

export default Room;