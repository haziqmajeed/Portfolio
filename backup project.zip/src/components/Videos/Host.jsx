import React, { Component } from 'react';
import { Grid, Button } from '@material-ui/core';
class Host extends Component {
    constructor(props) {
        super(props);
        
        
    }


    componentWillReceiveProps(nextProps){
     
        this.video.srcObject= nextProps.localStream
        
    }

    
    render() 
    
    { 
        
        return ( 
        
        <Grid container item xs={6} >
        <div>
            <video autoPlay ref= {(ref)=>{this.video = ref}} style={{backgroundColor:'black'}}></video>
            <h1>{this.props.myName}</h1>
            
        </div> 
        
        
        </Grid>
        
        );
    }
}
 
export default Host;