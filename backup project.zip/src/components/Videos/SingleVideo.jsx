import React, { Component } from 'react';
import { Grid, Button } from '@material-ui/core';
class SingleVideo extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            remotelyVideos:props.localStream,
            
         }
         
    }

    componentDidMount(){
     
        this.video.srcObject=  this.state.remotelyVideos.stream
    
    }

    

    

    
    render() 
    
    { 
        
        return ( 
        
        <Grid item xs={4} >
        <div>
            <video autoPlay ref= {(ref)=>{this.video = ref}} style={{backgroundColor:'black',width:"200px"}}></video>    
            <h2>{this.state.remotelyVideos.name}</h2>
        </div> 
        
        
        </Grid>
        
        );
    }
}
 
export default SingleVideo;