import { Grid } from '@material-ui/core'
import React, { Component } from 'react'
import Names from '../Names'
import SingleVideo from './SingleVideo'

class Vids extends Component {
    constructor(props) {
        super(props)  
        this.state = {
        remoteStreams:[],
      
        }
        
    }

    
    componentWillReceiveProps(nextProps){
        if (this.props.remoteStreams !== nextProps.remoteStreams) {
            this.setState({ 
                remoteStreams : nextProps.remoteStreams
            })

        }
        
       
        
    
       
    }
   

    
   


    render() { 
        
        
        return ( <div>

<Grid container spacing={1}>
          
          {this.state.remoteStreams.map((item,index) => ( 
            <SingleVideo  key={index} localStream={item}/>            
          ))}

         


</Grid>
            
            


        </div> );
    }
}
 
export default Vids;