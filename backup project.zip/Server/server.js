
const express = require('express')

var io = require('socket.io')
({
  path: '/haziq'
})

const {checkRoom,addUser, removeUser, getUser, getUsersInRoom } = require('./users');


const app = express()
const port = 8080


app.use(express.static('../build'))
app.get('/', (req, res, next) => {
  res.render('../build/index.html')
})
const server = app.listen(port, () => console.log(`listening on port ${port}!`))

io.listen(server)



const peers = io.of('/webrtcPeer')

let connectedPeers = new Map()

peers.on('connection', socket => {

  connectedPeers.set(socket.id, socket)
  
  socket.emit('connection-success', socket.id)

 

  const disconnectedPeer = (socketID) => socket.broadcast.emit('peer-disconnected', {
    peerCount: connectedPeers.size,
    socketID: socketID
  })

  socket.on('disconnect', () => {
    console.log('disconnected',socket.id)
    connectedPeers.delete(socket.id)
    removeUser(socket.id);
    disconnectedPeer(socket.id)
  })


  socket.on('getNames', data => {
    const users = getUsersInRoom(data.room)
    for (var temp of users){
      if(temp.id!== data.id){
        console.log("NAMES:",temp.name)
        socket.emit("getNames",{id:temp.id,name:temp.name})
      }
    }
  })





  socket.on('onlinePeers', (data) => {


    // for (const [socketID, _socket] of connectedPeers.entries()) {
    //   if (socketID !== data.id) {
       
    //     socket.emit('online-peer', socketID)
    //   }
    // }



    console.log("ROOM:" ,data.room)
    socket.join(data.room);
    const users = getUsersInRoom(data.room)

    if(users.length === 0){
      const type = "admin"
      const { error, user }=  addUser({ type , socket, id: socket.id, name:data.name, room:data.room });
      console.log(user.type);
    }
    else{
      const type = "participant"
        const { error, user }=  addUser({ type , socket, id: socket.id, name:data.name, room:data.room });
        console.log(user.type);
    }

    for (var temp of users){
      if(temp.id !== data.id){
      socket.emit('online-peer', temp.id)
      }
    }

  })

  

  socket.on('offer', data => {


    // for (const [socketID, socket] of connectedPeers.entries()) {
    //   if (socketID === data.remote) {
    //     socket.emit('offer', {
    //         sdp: data.sdp,
    //         socketID: data.local
    //       }
    //     )
    //   }
    // }


    const user = getUser(data.remote);

    const users = getUsersInRoom(user.room)

   

    for (var temp of users){
      if(temp.id === data.remote){
         temp.socket.emit('offer', {sdp:data.sdp,socketID: data.local})
      }
    }
   
  })




  socket.on('answer', (data) => {


    // for (const [socketID, socket] of connectedPeers.entries()) {
    //   if (socketID === data.remote) {
        
    //     socket.emit('answer', {
    //         sdp: data.sdp,
    //         socketID: data.local
    //       }
    //     )
    //   }
    // }


    const user = getUser(data.remote);
    const users = getUsersInRoom(user.room)
    for (var temp of users){
      if(temp.id === data.remote){
      temp.socket.emit('answer', {sdp: data.sdp,socketID: data.local})
      }
    }

 
  })

 

  
  socket.on('candidate', (data) => {


    // for (const [socketID, socket] of connectedPeers.entries()) {
    //   if (socketID === data.remote) {
    //     console.log("CNADIDATE:", data.candidate)
    //     socket.emit('candidate', {
    //       candidate: data.candidate,
    //       local: data.local
    //     })
    //   }
    // }


    const user = getUser(data.remote);

    const users = getUsersInRoom(user.room)

   

    for (var temp of users){
      if(temp.id === data.remote){
      temp.socket.emit('candidate', {candidate:data.candidate,local:data.local})
      }
    }

 
  })

})